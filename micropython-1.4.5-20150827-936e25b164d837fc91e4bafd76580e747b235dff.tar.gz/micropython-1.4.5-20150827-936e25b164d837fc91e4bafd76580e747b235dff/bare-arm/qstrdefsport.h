// qstrs specific to this port
