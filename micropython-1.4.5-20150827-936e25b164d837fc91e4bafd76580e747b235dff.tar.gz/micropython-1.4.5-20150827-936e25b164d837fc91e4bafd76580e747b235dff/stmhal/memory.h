// this is needed for extmod/crypto-algorithms/sha256.c
#include <string.h>
