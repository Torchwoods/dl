// dummy file to keep build system homogeneous across MCU series
