def pformat(obj):
    return repr(obj)
