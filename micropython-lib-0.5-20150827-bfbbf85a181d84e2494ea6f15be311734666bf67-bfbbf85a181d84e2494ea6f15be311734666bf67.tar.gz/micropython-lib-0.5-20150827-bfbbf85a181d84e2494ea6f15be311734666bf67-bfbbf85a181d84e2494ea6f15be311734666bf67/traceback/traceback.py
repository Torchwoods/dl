def format_tb(tb, limit):
    return ["traceback.format_tb() not implemented\n"]

def format_exception_only(type, value):
    return [repr(value) + "\n"]
