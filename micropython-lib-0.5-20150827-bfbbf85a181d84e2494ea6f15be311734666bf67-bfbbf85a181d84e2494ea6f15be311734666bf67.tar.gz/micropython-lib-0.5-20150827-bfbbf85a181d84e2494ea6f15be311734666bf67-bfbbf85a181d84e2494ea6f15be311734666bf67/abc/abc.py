def abstractmethod(f):
    return f
